package com.example.crud_json;

public class Config {
    //Agregando las direcciones de los srcipts del crud
    public static final String URL_ADD = "http://192.168.1.67:8090/Android/CRUD/addtmp.php";
    public static final String URL_GET_ALL = "http://192.168.1.67:8090/Android/CRUD/getAllEmp.php";
    public static final String URL_GET_EMP = "http://192.168.1.67:8090/Android/CRUD/getEmp.php";
    public static final String URL_UPDATE_EMP = "http://192.168.1.67:8090/Android/CRUD/updateEmp.php";
    public static final String URL_DELETE_EMP = "http://192.168.1.67:8090/Android/CRUD/deleteEmp.php";

    //Definiendo las constants para ser usadas en los requerimientos a los scripts PHP
    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAME = "name";
    public static final String KEY_EMP_DESG = "desg";
    public static final String KEY_EMP_SAL = "salary";

    //JSON tags
    public static String TAG_JSON_ARRAY = "result";
    public static String TAG_ID = "id";
    public static String TAG_NAME = "name";
    public static String TAG_DESG = "desg";
    public static String TAG_SAL = "salary";

    public static String EMP_ID = "emp_id";
}/*End*/